from django.contrib import admin
from user.models import User,project_files


admin.site.register(User)
admin.site.register(project_files)
