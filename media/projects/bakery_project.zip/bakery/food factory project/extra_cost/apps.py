from django.apps import AppConfig


class ExtraCostConfig(AppConfig):
    name = 'extra_cost'
