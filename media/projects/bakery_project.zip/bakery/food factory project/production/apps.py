from django.apps import AppConfig


class ProductionConfig(AppConfig):
    name = 'production'
