from django.apps import AppConfig


class ExternalCostConfig(AppConfig):
    name = 'external_cost'
