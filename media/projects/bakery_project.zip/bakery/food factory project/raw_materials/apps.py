from django.apps import AppConfig


class RawMaterialsConfig(AppConfig):
    name = 'raw_materials'
